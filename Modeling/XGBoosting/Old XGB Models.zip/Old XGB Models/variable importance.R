
require(caret)

load("Modeling/GBM Models/Old Models/SN_gbmModel.RData")

gbmImp <- varImp(gbmFit,scale=FALSE)


gbmImp <- as.vector(gbmImp)
plot(gbmImp)[1:10,]
